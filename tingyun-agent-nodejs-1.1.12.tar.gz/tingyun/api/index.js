var logger = require('../util/logger.js').child('API');

function API(agent) {
	if (!agent) {
		throw new Error('Agent is null in API');
	}
	this.agent = agent;
}

API.prototype = {
	getBrowserMonitorScript: function() {
		var action = this.agent.getAction(),
			scriptConfig,
			traceInfo,
			agentStatics,
			remoteScript,
			pos,
			script = '';
		if (!action) {
			logger.error('Action is null in API');
			return script;
		}
		if (!this.agent.config) {
			logger.error('Config is null in API');
			return script;
		}
		scriptConfig = this.agent.config.rum;
		if (scriptConfig.enabled && scriptConfig.ratio > Math.random(0, 1)) {
			remoteScript = scriptConfig.script;
			if (!remoteScript) {
				logger.error("Script did not return from server side.");
				return script;
			}
			traceInfo = action.getTraceDurations();
			if (!traceInfo) {
				logger.error("Action's traceInfo is null");
				return script;
			}
			try {
				traceInfo = JSON.parse(traceInfo);
				if (!traceInfo) {
					logger.error("parse action's traceInfo error");
					return script;
				}
			} catch(e) {
				logger.error("parse action's traceInfo error");
				return script;
			}
			agentStatics = {
	            id: traceInfo.id,
	            n: traceInfo.action,
	            a: parseInt(traceInfo.time.duration),
	            q: parseInt(traceInfo.time.qu),
	            tid: traceInfo.trId
	        };
	        var pos = remoteScript.lastIndexOf('}');
	        agentStatics = JSON.stringify(agentStatics);
	        script = remoteScript.substr(0, pos) + ';ty_rum.agent = ' + agentStatics + ';' + remoteScript.substr(pos);
         	script = '<script type="text/javascript" data-tingyun="tingyun">' + script + '</script>';
		} else {
			logger.debug('Server side configuration(rum.enabled) is disabled, or randomly choose not to monitor.');
		}
		return script;
	}
};

module.exports = API;