'use strict';
function CallStack(data, skip) {
    var ex = new Error("");
    var ret = ex.stack || ex.toString();
    var start = skip ? skip + 2: 2;
    ret = ret.split('\n').slice(start);
    while ( ret.length > 0 && ret[0].indexOf('/node_modules/tingyun/') >= 0 ) ret.shift();
    for ( var i = 0; i < ret.length; i++ ) {
        ret[i] = ret[i].replace('    at ', '');
    }
    if ( data ) ret.unshift(data);
    return ret;
}
module.exports = CallStack;
