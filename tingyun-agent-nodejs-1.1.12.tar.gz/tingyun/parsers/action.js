'use strict';

var urltils = require('../util/urltils.js')
    , Metrics = require('../metrics/metrics.js')
    , Timer   = require('../util/timer.js')
    , Trace   = require('../metrics/trace.js')
    ;
//通过捕获开始和结束事件 计算代码执行时间和数据库执行时间
//重叠时间不重复统计
function TimeRecord() {
    this.time_value = [0, 0];
    this.used = 0;
    this.start = process.hrtime();
}
TimeRecord.prototype.inc = function inc() {
    this.used++;
    if ( this.used > 1 ) return;
    this.start = process.hrtime();
}
TimeRecord.prototype._append_time = function append_time(hrtime) {
    this.time_value[0] += hrtime[0];
    this.time_value[1] += hrtime[1];
    if ( this.time_value[1] >= 1000000000 ) {
        this.time_value[0] += 1; this.time_value[1] -= 1000000000;
    }
}
TimeRecord.prototype.dec = function dec() {
    if ( this.used == 0 ) return;
    this.used--;
    if ( this.used == 0 ) {
        this._append_time(process.hrtime(this.start));
    }
}
TimeRecord.prototype.value = function value() {
    return Math.round(this.time_value[0] * 1000 + this.time_value[1] / 1000000.0);
}
var last_time = Date.now();
var last_num = 0;
function get_id(preid) {
    var top_time = Date.now();
    last_num = ( top_time == last_time )? last_num + 1: 0;
    last_time = top_time;
    var rand_id = last_time.toString(32) + last_num.toString(32);
    if ( preid && typeof preid === 'number' ) rand_id = preid.toString(32) + rand_id;
    var patch = '0000000000000000';
    return patch.slice(0, 16 - rand_id.length) + rand_id;
}
function Action(agent) {
    this.code_time = new TimeRecord();
    this.db_time = new TimeRecord();
    this.agent = agent;
    this.metrics = new Metrics( agent.config.apdex_t, agent.mapper, agent.metricNameNormalizer );

//    this.id = Math.floor((Math.random() * 1e17)).toString(16);
    this.id = get_id( agent.config.applicationId );

    this.exceptions = [];
    this.timer = new Timer();
    this.timer.begin();

    this.url         = null;
    this.name        = null;
    this.partialName = null;
    this.statusCode  = null;
    this.error       = null;
    this.verb        = null;
    this.trace       = null;
    this.forceIgnore = null;
    this.ignore      = false;
    this.webSegment  = null;
    this.bgSegment   = null;
    this.catResponseTime = 0;
    this.pathHashes  = [];
    this.thrift = {};
}

Action.prototype.getTrace = function getTrace() {
    if (!this.trace) this.trace = new Trace(this);
    return this.trace;
};

Action.prototype.isWeb = function isWeb() { return this.url ? true : false; };
Action.prototype.isActive = function isActive() { return this.timer.isActive(); };
Action.prototype.end = function end() {
    if (!this.timer.isActive()) return;
    if ( typeof this.block_time !== 'undefined' ) {
        this.metrics.measureMilliseconds('WebFrontend/NULL/QueueTime', null, this.block_time, 0);
    }
    this.timer.end();
    if (this.trace) this.trace.end();
    this.agent.emit('ActionEnd', this);
};

Action.prototype.applyUserNamingRules = function applyUserNamingRules(requestUrl) {
    var normalizer = this.agent.userNormalizer;
    if (normalizer.isIgnored(requestUrl)) this.ignore = true;
    if (normalizer.isNormalized(requestUrl)) this.setPartialName('NormalizedUri' + normalizer.normalize(requestUrl));
};

Action.prototype.setPartialName = function setPartialName(name) {
    this.partialName = name;
};
Action.prototype.setName = function setName(requestURL, statusCode) {
    var normalizer;
    this.originalUrl = requestURL;
    this.url = urltils.scrub(requestURL);
    this.statusCode = statusCode;
    this.applyUserNamingRules(this.url);
    normalizer = this.agent.urlNormalizer;
    if (normalizer.isIgnored(this.url)) this.ignore = true;
    if (!this.partialName) this.setPartialName(normalizer.normalize(this.url));
    normalizer = this.agent.actionNameNormalizer;
    var fullName = 'WebAction/' + this.partialName;
    if (normalizer.isIgnored(fullName)) this.ignore = true;
    this.name = normalizer.normalize(fullName);
    if (this.forceIgnore === true || this.forceIgnore === false) this.ignore = this.forceIgnore;
};

Action.prototype.setCustom = function setCustom(header, _httpStatus) {
    var trace = this.getTrace();
    trace.custom = {
        referer : ( (header && header.referer) ? header.referer: ""),
        httpStatus : _httpStatus,
        threadName : ''
    };
}

Action.prototype.measure = function measure(name, scope, duration, exclusive) {
    this.metrics.measureMilliseconds(name, scope, duration, exclusive);
};

Action.prototype.setApdex = function setApdex(name, duration, apdex_t) {
    var apdex = this.metrics.ApdexMetric(name, apdex_t);
    if (urltils.errorMatch(this.agent.config, this.statusCode)) apdex.incFrustrating();
    else apdex.add(duration);
};
Action.prototype.get_name = function () {
    return this.agent.actionNameNormalizer.normalize('WebAction/' + (this.partialName?this.partialName:this.agent.urlNormalizer.normalize(this.url)));
}
Action.prototype.getTraceDurations = function () {
    var trace = this.getTrace();
    var result = trace.getTraceDurations();
    var pice_array = [];
    //添加block, queuetime
    result.qu = (typeof this.block_time !== 'undefined')?this.block_time:0;
    result.duration = trace.getDurationInMillis();
    result.code = (result.svc < result.duration)?(result.duration - result.svc):0;
    delete result.svc;
    var id = this.agent.config.transaction_tracer.tingyunIdSecret;
    if (id) {
        id = id.slice(id.indexOf('|') + 1);
    }
    // round result.
    for (var key in result) {
        if (typeof result[key] === 'number') {
            result[key] = Math.round(result[key]);
        }
    }
    var ret = {
        id: id,
        action: this.get_name(),
        trId: this.id,
        time: result
    };
    return JSON.stringify(ret);
}

module.exports = Action;
