'use strict'
var shimmer = require('../../util/shimmer');

module.exports = function initialize(agent, Promise) {

  var tracer = agent.tracer;

  shimmer.wrapMethod(Promise.prototype, 'Promise.prototype', '_resolveFromResolver', wrapResolveFromResolver);

  function wrapResolveFromResolver(_resolveFromResolver) {
    return tracer.segmentProxy(function(resolver) {
      return _resolveFromResolver.apply(this, arguments);
    });
  }

  shimmer.wrapMethod(Promise.prototype, 'Promise.prototype', '_then', wrapThen);

  function wrapThen(_then) {
    return tracer.segmentProxy(function(fulfill, reject, progress, promise, receiver, domain) {
      var args = [];
      args.push(wrapFunction(fulfill));
      args.push(wrapFunction(reject));
      args.push(wrapFunction(progress));
      args.push(promise);
      args.push(receiver);
      args.push(domain);

      return _then.apply(this, args);

      function wrapFunction(func) {
        if (typeof func === 'function') {
          return tracer.callbackProxy(func);
        } else {
          return func;
        }
      }
    });
  }
};