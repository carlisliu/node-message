var shimmer = require('../../util/shimmer');
var logger = require('../../util/logger').child('parsers.wrappers.ws');
var recordWeb = require('../../metrics/recorders/http.js');

module.exports = function initialize(agent, ws) {
    if (!ws || !ws.Server || !ws.Server.prototype) {
        return;
    }

    var tracer = agent.tracer;

    function idMatch(a, b) {
        var bResult = b.slice(0, b.indexOf('|'));
        return bResult === a ? true : (a.slice(0, a.indexOf('|')) == bResult ? true : a.slice(0, a.indexOf(';')) == bResult);
    }

    shimmer.wrapMethod(ws.Server.prototype, 'ws.Server.prototype', 'handleUpgrade', function(_handleUpgrade) {
        return function(req, socket, upgradeHead, cb) {
            var headers = req.headers;
            if (headers) {
                var xTingyunId = headers['x-tingyun-id'];

                if (xTingyunId) {
                    logger.debug('ws got header x-tingyun-id(%s)', xTingyunId);
                    var secretId = agent.config.transaction_tracer.tingyunIdSecret;
                    if (secretId) {
                        if (idMatch(xTingyunId, secretId)) {
                            setTxData.call(this, req, secretId);
                        } else {
                            logger.debug('Id does not match, probably because client is not under the same account with server.');
                        }
                    } else {
                        logger.debug('can not read agent.config.transaction_tracer.tingyunIdSecret, check dc configuration or server connection');
                    }
                } else {
                    logger.debug('no x-tingyun-id header');
                }
            } else {
                logger.debug('Request does not contain any header property.');
            }

            return _handleUpgrade.call(this, req, socket, upgradeHead, cb);

            function setTxData(req, secretId) {
                this.on('headers', function(headers) {
                    var action;
                    var id = secretId.slice(secretId.indexOf('|') + 1);
                    if (req) {
                        action = req.url;
                    }
                    var txData = JSON.stringify({
                        id: id,
                        action: 'WebAction/' + (action || '')
                    });
                    logger.debug('txData is:', txData);

                    headers.push('X-Tingyun-Tx-Data: ' + txData);
                });
            }
        }
    });

    shimmer.wrapMethod(ws.Server.prototype, 'ws.Server.prototype', 'on', function(_on) {
        return function(event, listener) {
            var _listener = listener;
            if (event == 'connection') {
                _listener = wrapListener(listener);
            }
            return _on.call(this, event, _listener);
        }
    });

    function wrapListener(listener) {
        return function() {
            var length = arguments.length;
            var args = new Array(length);
            for (var i = 0; i < length; i++) {
                args[i] = arguments[i];
            }
            wrapWsClientOn(args);

            return listener.apply(this, args);
        }
    }

    function wrapWsClientOn(args) {
        if (args && args[0] && args[0].on) {
            shimmer.wrapMethod(args[0], 'ws.on', 'on', function(_on) {
                return function(event, listener) {
                    var _listener;
                    if (event == 'message' && typeof listener === 'function') {
                        _listener = wrapMessageListener(listener);
                    } else {
                        _listener = listener;
                    }
                    return _on.call(this, event, _listener);
                }
            });
        }

        function wrapMessageListener(listener) {
            return tracer.actionProxy(function() {
                var action = tracer.getAction();
                var segment;
                if (action) {
                    var url = ('ws://' + (this.upgradeReq && this.upgradeReq.url || '')).replace(/\//g, "%2F");
                    var segmentInfo = {
                        metric_name: "NodeJS/NULL/" + url,
                        call_url: "",
                        call_count: 1,
                        class_name: 'WebSocket',
                        method_name: 'onMessage',
                        params: {}
                    };
                    segment = tracer.addSegment(segmentInfo, recordWeb);
                    logger.debug('ws segment(%s) added. url(%s)', segment.name, url);
                    action.url = url;
                action.name = "WebAction/ws/WebSocket/onMessage";
                action.statusCode = 200;
                }
                var result;
                try {
                    result = listener.apply(this, arguments);
                } catch (e) {
                    if (action) {
                    action.statusCode = 500;
                }
                }
                segment && segment.end();
                action && action.end();
                return result;
            });
        }
    }

};