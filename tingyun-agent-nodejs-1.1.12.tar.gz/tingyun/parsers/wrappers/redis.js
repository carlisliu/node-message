'use strict';

var shimmer = require('../../util/shimmer');
var logger  = require('../../util/logger').child('parsers.wrappers.redis');
var record = require('../../metrics/recorders/cache_storage.js')('Redis');
var cmd_map = require('./redis-common/command');
    
function get_addr(obj) {
    var server = obj.host? obj.host:(obj.address?obj.address.split(':')[0]:'localhost');
    var server_port = 6379;
    if ( obj.port ) server_port = obj.port;
    else if ( obj.address ) {
        var addr = obj.address.split(':');
        if ( addr.length > 1 ) server_port = addr[1];
    }
    return {host:server, port: server_port }
}

module.exports = function initialize(agent, redis) {
    var tracer = agent.tracer;
    if ( ! (redis && redis.RedisClient && redis.RedisClient.prototype) ) return;
    shimmer.wrapMethod(redis.RedisClient.prototype, 'redis.RedisClient.prototype', 'send_command', function wrapper(send_command) {
            return tracer.segmentProxy(function wrapped() {
                if ( ! agent.config.enabled ) return send_command.apply(this, arguments);

                if (!tracer.getAction() || arguments.length < 1) return send_command.apply(this, arguments);
                var action = tracer.getAction();
                var args   = tracer.slice(arguments);
                var addr   = get_addr(this);
                var name   = 'Redis/' + addr.host + ':' + addr.port + '/' + cmd_map.__name_map(args[0]);

                var segment_info = {
                    metric_name : name,
                    call_url: "",
                    call_count:1,
                    class_name:"redis.RedisClient",
                    method_name: 'send_command.' + args[0],
                    params : {}
                }
                var segment     = tracer.addSegment(segment_info, record)
                    , position    = args.length - 1
                    , keys        = args[1]
                    , last        = args[position]
                    ;

                if (agent.config.capture_params && keys && typeof keys !== 'function' && agent.config.ignored_params.indexOf('key') === -1) {
                    segment.parameters.key = JSON.stringify([keys[0]]);
                }

//                segment.port = addr.port;
//                segment.host = addr.host

                function proxy(target) {
                    return function cls_finalize() {
                        segment.end();
                        return target.apply(this, arguments);
                    };
                }

                if (typeof last === 'function') {
                    args[position] = tracer.callbackProxy(proxy(last));
                }
                else if (Array.isArray(last) && typeof last[last.length - 1] === 'function') {
                    var callback = proxy(last[last.length - 1]);
                    last[last.length - 1] = tracer.callbackProxy(callback);
                }
                else {
                    args.push(function cb() { segment.end(); });
                }

                return send_command.apply(this, args);
            });
        });
};
