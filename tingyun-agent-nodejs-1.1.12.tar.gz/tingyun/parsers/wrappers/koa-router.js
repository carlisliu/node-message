var shimmer = require('../../util/shimmer.js');
var logger = require('../../util/logger.js').child('parsers.wrappers.koa-router');
var urltils = require('../../util/urltils.js');

module.exports = function initialize(agent, Router) {

    var tracer = agent.tracer;
    var slice = Array.prototype.slice;

    if (!Router || !Router.prototype) {
        return logger.verbose("Koa Router's prototype does not exists.");
    }

    shimmer.wrapMethodOnce(Router.prototype, 'Router.prototype', 'register', function(register) {
        return function() {
            var args = slice.call(arguments, 0);
            var middleware = args[2];
            if (Array.isArray(middleware)) {
                middleware.unshift(intercept);
            } else {
                middleware = [intercept, middleware]
            }
            args[2] = middleware;
            return register.apply(this, args);
        };

        function* intercept(next) {
            if (this._matchedRoute) {
                var actionId = this.method + " " + this._matchedRoute;
                var action = agent.getAction();
                if (action) {
                    var segment = tracer.getSegment();
                    segment.parameters = segment.parameters || {};
                    var params = this.query;
                    urltils.copyParameters(agent.config, params, segment.parameters);
                    urltils.copyParameters(agent.config, this.params || {}, segment.parameters);
                    action.setPartialName('Koa/' + actionId.replace(/\//g, "%2F"));
                }
            }
            yield next;
        }
    });
};