var shimmer = require('../../util/shimmer.js');
var logger = require('../../util/logger.js').child('parsers.wrappers.koa');
var record = require('../../metrics/recorders/generic.js');

module.exports = function initialize(agent, Application) {

    var tracer = agent.tracer;

    if (!Application || !Application.prototype) {
        return logger.verbose("Application's prototype does not exists.");
    }

    shimmer.wrapMethodOnce(Application.prototype, 'Application.prototype', 'callback', function(callback) {
        return function() {

            agent.environment.setDispatcher('Koa');
            agent.environment.setFramework('Koa');

            var listener = callback.apply(this, arguments);

            var i = -1;
            this.middleware.some(function(_middleware) {
                if (_middleware.__View) {
                    ++i;
                    return true;
                }
            });
            if (i > -1) {
                this.middleware.splice(i + 1, 0, function*(next) {
                    var _self = this;
                    var render = this.render;
                    if (typeof render === 'function') {
                        this.render = wrapRender(agent, tracer, _self, render);
                    }
                    yield next;
                });
            }
            /*var exists = false;
            var j = -1;
            this.middleware.some(function(_middleware) {
                if (_middleware.router) {
                    j++;
                    return (exists = true);
                }
            });
            if (j > -1) {
                this.middleware.splice(j + 1, 0, function*(next) {
                    console.log(this.matched);
                    yield next;
                });
            }
            console.log('router exists....');*/

            this.on('error', function (error, context) {
                var action = context.res._tingyunAction;
                    if (action) {
                    var status = error.status || 500;
                    action.statusCode = status;
                        action.exceptions.push(error);
                    } else {
                        agent.errors.add(null, error);
                    }
                });

            return function _listener(req, res) {
                res._tingyunAction = agent.getAction();
                return listener.apply(this, arguments);
            };

            function wrapRender(agent, tracer, context, render) {
                return function*(view, locals) {
                    var action = tracer.getAction();
                    if (agent.config.enabled && action) {
                        var className = 'Application';
                        var name = "Koa/" + className + '/render';
                        var segmentInfo = {
                            metric_name: name,
                            call_url: "",
                            call_count: 1,
                            class_name: className,
                            method_name: "render",
                            params: {}
                        }
                        var segment = tracer.addSegment(segmentInfo, record);
                        yield render.apply(context, arguments);
                        segment.end();
                    } else {
                        yield render.apply(context, arguments);
                    }
                };
            }
        };
    });

};