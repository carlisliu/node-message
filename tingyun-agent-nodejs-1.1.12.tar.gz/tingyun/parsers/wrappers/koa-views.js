var shimmer = require('../../util/shimmer.js');
var logger = require('../../util/logger.js').child('parsers.wrappers.koa-views');

module.exports = function initialize(agent, View) {

    if (!View) {
        return logger.verbose("View does not exists.");
    }

    return function () {
        var view = View.apply(this, arguments);
        view.__View = true;
        return view;
    };
};